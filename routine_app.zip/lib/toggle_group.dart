
import 'package:flutter/material.dart';

class ToggleGroup extends StatefulWidget {
  @override
  _ToggleGroupState createState() => _ToggleGroupState();
}

class _ToggleGroupState extends State<ToggleGroup> {
  final List<String> options = ["Day", "Week", "Month"];
  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(options.length, (index) {
        bool isSelected = index == selectedIndex;
        return GestureDetector(
          onTap: () => setState(() => selectedIndex = index),
          child: AnimatedContainer(
            duration: Duration(milliseconds: 300),
            curve: Curves.easeInOut,
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            margin: EdgeInsets.symmetric(horizontal: 4),
            decoration: BoxDecoration(
              color: isSelected ? cs.primary : cs.surfaceVariant,
              borderRadius: BorderRadius.horizontal(
                left: Radius.circular(index == 0 ? 40 : 16),
                right: Radius.circular(index == options.length - 1 ? 40 : 16),
              ),
            ),
            child: Text(
              options[index],
              style: TextStyle(
                color: isSelected ? cs.onPrimary : cs.onSurfaceVariant,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        );
      }),
    );
  }
}
