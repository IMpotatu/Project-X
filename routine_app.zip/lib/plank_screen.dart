
import 'package:flutter/material.dart';

class PlankScreen extends StatefulWidget {
  @override
  _PlankScreenState createState() => _PlankScreenState();
}

class _PlankScreenState extends State<PlankScreen> {
  bool isRunning = true;
  int seconds = 60;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      backgroundColor: cs.surfaceVariant,
      appBar: AppBar(
        title: Text('Plank'),
        centerTitle: true,
        backgroundColor: cs.surface,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            '${seconds ~/ 60}:${(seconds % 60).toString().padLeft(2, '0')}',
            style: TextStyle(fontSize: 72, color: cs.primary),
          ),
          const SizedBox(height: 40),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: cs.primary,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(40),
              ),
              padding: EdgeInsets.symmetric(horizontal: 64, vertical: 20),
            ),
            onPressed: () {
              setState(() => isRunning = !isRunning);
            },
            child: Text(isRunning ? 'Pause' : 'Start',
                style: TextStyle(fontSize: 18, color: cs.onPrimary)),
          ),
        ],
      ),
    );
  }
}
