
import 'package:flutter/material.dart';
import 'toggle_group.dart';
import 'plank_screen.dart';
import 'breathing_screen.dart';

class RoutineDashboard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(title: Text("My Routines")),
      backgroundColor: cs.surfaceVariant,
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            ToggleGroup(),
            SizedBox(height: 30),

            RoutineCard(
              icon: Icons.self_improvement,
              title: "Breathing",
              duration: "3 mins",
              onTap: () {
                Navigator.push(context,
                  MaterialPageRoute(builder: (_) => BreathingScreen()));
              },
            ),

            RoutineCard(
              icon: Icons.fitness_center,
              title: "Plank",
              duration: "1 min",
              onTap: () {
                Navigator.push(context,
                  MaterialPageRoute(builder: (_) => PlankScreen()));
              },
            ),

            Spacer(),
            Text("🔥 5 Day Streak",
              style: TextStyle(color: cs.primary, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

class RoutineCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String duration;
  final VoidCallback onTap;

  RoutineCard({
    required this.icon,
    required this.title,
    required this.duration,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.only(bottom: 20),
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: cs.primaryContainer,
          borderRadius: BorderRadius.circular(30),
        ),
        child: Row(
          children: [
            Icon(icon, size: 36, color: cs.onPrimaryContainer),
            SizedBox(width: 20),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                  style: TextStyle(fontSize: 18, color: cs.onPrimaryContainer)),
                Text(duration,
                  style: TextStyle(fontSize: 14, color: cs.onPrimaryContainer)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
