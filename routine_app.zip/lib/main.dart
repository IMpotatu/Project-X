
import 'package:flutter/material.dart';
import 'routine_dashboard.dart';
import 'plank_screen.dart';
import 'breathing_screen.dart';

void main() => runApp(RoutineApp());

class RoutineApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Routine',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
      home: RoutineDashboard(),
    );
  }
}
